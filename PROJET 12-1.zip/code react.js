
// App.js

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';

const API_BASE_URL = 'http://localhost:3000';

function App() {
    const [equipments, setEquipments] = useState([]);
    const [reservations, setReservations] = useState([]);
    const [auditLog, setAuditLog] = useState([]);
    const [nonConformities, setNonConformities] = useState([]);

    const [newEquipmentName, setNewEquipmentName] = useState('');
    const [newEquipmentDescription, setNewEquipmentDescription] = useState('');
    const [newReservationEquipmentId, setNewReservationEquipmentId] = useState('');
    const [newReservationUserId, setNewReservationUserId] = useState('');
    const [newReservationStartTime, setNewReservationStartTime] = useState('');
    const [newReservationEndTime, setNewReservationEndTime] = useState('');
    const [newNonConformityEquipmentId, setNewNonConformityEquipmentId] = useState('');
    const [newNonConformityDescription, setNewNonConformityDescription] = useState('');

    const [currentUserId, setCurrentUserId] = useState('user123'); // Simuler un utilisateur connecté
    const [isAdmin, setIsAdmin] = useState(true); // Simuler un rôle admin

    useEffect(() => {
        fetchEquipments();
        fetchReservations();
        fetchAuditLog();
        fetchNonConformities();
    }, []);

    // Data Fetching
    const fetchEquipments = async () => { try { const res = await axios.get(`${API_BASE_URL}/equipments`); setEquipments(res.data); } catch (err) { console.error('Error fetching equipments:', err); } };
    const fetchReservations = async () => { try { const res = await axios.get(`${API_BASE_URL}/reservations`); setReservations(res.data); } catch (err) { console.error('Error fetching reservations:', err); } };
    const fetchAuditLog = async () => { try { const res = await axios.get(`${API_BASE_URL}/audit-log`, { headers: { 'user-id': currentUserId } }); setAuditLog(res.data); } catch (err) { console.error('Error fetching audit log:', err); } };
    const fetchNonConformities = async () => { try { const res = await axios.get(`${API_BASE_URL}/non-conformities`, { headers: { 'user-id': currentUserId } }); setNonConformities(res.data); } catch (err) { console.error('Error fetching non-conformities:', err); } };

    // Creation Handlers
    const createEquipment = async () => {
        try {
            await axios.post(`${API_BASE_URL}/equipments`, { name: newEquipmentName, description: newEquipmentDescription }, { headers: { 'user-id': currentUserId } });
            fetchEquipments(); setNewEquipmentName(''); setNewEquipmentDescription('');
        } catch (err) { console.error('Error creating equipment:', err); }
    };

    const createReservation = async () => {
        try {
            await axios.post(`${API_BASE_URL}/reservations`, { equipmentId: newReservationEquipmentId, userId: newReservationUserId, startTime: newReservationStartTime, endTime: newReservationEndTime }, { headers: { 'user-id': currentUserId } });
            fetchReservations(); setNewReservationEquipmentId(''); setNewReservationUserId(''); setNewReservationStartTime(''); setNewReservationEndTime('');
        } catch (err) { console.error('Error creating reservation:', err); }
    };

    const createNonConformity = async () => {
        try {
            await axios.post(`${API_BASE_URL}/non-conformities`, { equipmentId: newNonConformityEquipmentId, description: newNonConformityDescription }, { headers: { 'user-id': currentUserId } });
            fetchNonConformities(); setNewNonConformityEquipmentId(''); setNewNonConformityDescription('');
        } catch (err) { console.error('Error creating non-conformity:', err); }
    };

    // Deletion Handler
    const deleteReservation = async (id) => {
        try { await axios.delete(`${API_BASE_URL}/reservations/${id}`, { headers: { 'user-id': currentUserId } }); fetchReservations(); } catch (err) { console.error('Error deleting reservation:', err); }
    };

    // Input Change Handlers
    const handleInputChange = (setState) => (e) => setState(e.target.value);

    return (
        <div className="app-container">
            <h1>Equipment Management</h1>

            {isAdmin && (
                <section className="section">
                    <h2>Create Equipment</h2>
                    <input type="text" placeholder="Name" value={newEquipmentName} onChange={handleInputChange(setNewEquipmentName)} />
                    <input type="text" placeholder="Description" value={newEquipmentDescription} onChange={handleInputChange(setNewEquipmentDescription)} />
                    <button onClick={createEquipment}>Create</button>
                </section>
            )}

            <section className="section">
                <h2>Equipment List</h2>
                <ul>{equipments.map(e => <li key={e.id}>{e.name} - {e.description}</li>)}</ul>
            </section>

            <section className="section">
                <h2>Create Reservation</h2>
                <input type="text" placeholder="Equipment ID" value={newReservationEquipmentId} onChange={handleInputChange(setNewReservationEquipmentId)} />
                <input type="text" placeholder="User ID" value={newReservationUserId} onChange={handleInputChange(setNewReservationUserId)} />
                <input type="datetime-local" placeholder="Start Time" value={newReservationStartTime} onChange={handleInputChange(setNewReservationStartTime)} />
                <input type="datetime-local" placeholder="End Time" value={newReservationEndTime} onChange={handleInputChange(setNewReservationEndTime)} />
                <button onClick={createReservation}>Create Reservation</button>
            </section>

            <section className="section">
                <h2>Reservation List</h2>
                <ul>{reservations.map(r => <li key={r.id}>Equipment: {r.equipmentId}, User: {r.userId}, Start: {r.startTime}, End: {r.endTime} <button onClick={() => deleteReservation(r.id)}>Cancel</button></li>)}</ul>
            </section>

            <section className="section">
                <h2>Report Non-Conformity</h2>
                <input type="text" placeholder="Equipment ID" value={newNonConformityEquipmentId} onChange={handleInputChange(setNewNonConformityEquipmentId)} />
                <input type="text" placeholder="Description" value={newNonConformityDescription} onChange={handleInputChange(setNewNonConformityDescription)} />
                <button onClick={createNonConformity}>Report</button>
            </section>

            {isAdmin && (
                <section className="section">
                    <h2>Audit Log</h2>
                    <ul>{auditLog.map(log => <li key={log.id}>User: {log.userId}, Action: {log.action}, Details: {JSON.stringify(log.details)}, Time: {log.timestamp}</li>)}</ul>
                </section>
            )}

            {isAdmin && (
                <section className="section">
                    <h2>Non-Conformity List</h2>
                    <ul>{nonConformities.map(nc => <li key={nc.id}>Equipment: {nc.equipmentId}, User: {nc.userId}, Desc: {nc.description}, Time: {nc.timestamp}</li>)}</ul>
                </section>
            )}
        </div>
    );
}

export default App;

