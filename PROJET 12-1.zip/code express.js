
const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const { v4: uuidv4 } = require('uuid'); // Pour générer des IDs uniques
const cors = require('cors'); // Pour gérer les requêtes cross-origin (utile pour le front-end)

// Middleware
app.use(bodyParser.json());
app.use(cors());


//  Simuler une base de données (à remplacer par une vraie base de données comme MongoDB, PostgreSQL, etc.)
let equipments = [];
let reservations = [];
let users = []; // Pour la gestion des utilisateurs et leurs rôles (admin, utilisateur standard)
let auditLog = []; // Pour le journal des activités
let nonConformities = []; // Pour les rapports de non-conformité


// --------------------------------------------------
// Utilitaires (à séparer dans un fichier utils.js)
// --------------------------------------------------

// Fonction pour formater la date et l'heure
function formatDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Janvier est 0!
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');

    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}


// Fonction pour enregistrer une action dans le journal d'audit
function logActivity(userId, action, details) {
    const timestamp = formatDate(new Date());
    const logEntry = {
        id: uuidv4(), // ID unique pour chaque entrée de log
        userId,
        timestamp,
        action,
        details
    };
    auditLog.push(logEntry);
    console.log(`[AUDIT] ${timestamp} - User ${userId} - ${action}: ${JSON.stringify(details)}`);
}


// Fonction pour vérifier si un utilisateur a un rôle spécifique (ex: 'admin')
function hasRole(userId, role) {
    const user = users.find(u => u.id === userId);
    if (!user) return false;
    return user.roles && user.roles.includes(role);
}

// Middleware pour l'authentification (exemple basique)
function authenticate(req, res, next) {
    const userId = req.headers['user-id']; // Récupère l'ID de l'utilisateur depuis l'en-tête (pour simplifier l'exemple)
    if (!userId) {
        return res.status(401).json({ message: 'Authentification requise.' });
    }

    const user = users.find(u => u.id === userId);
    if (!user) {
        return res.status(401).json({ message: 'Utilisateur non trouvé.' });
    }

    req.user = user; // Ajoute l'utilisateur à l'objet requête pour l'utiliser dans les routes
    next();
}


// --------------------------------------------------
// Routes pour les équipements
// --------------------------------------------------

// Créer un équipement (accessible uniquement aux administrateurs)
app.post('/equipments', authenticate, (req, res) => {
    if (!hasRole(req.user.id, 'admin')) {
        return res.status(403).json({ message: 'Accès interdit.  Seuls les administrateurs peuvent créer des équipements.' });
    }

    const newEquipment = {
        id: uuidv4(),
        name: req.body.name,
        description: req.body.description,
        available: true,
        // Ajoutez d'autres propriétés selon vos besoins
    };

    equipments.push(newEquipment);
    logActivity(req.user.id, 'Create Equipment', { equipmentId: newEquipment.id, equipmentName: newEquipment.name });
    res.status(201).json(newEquipment);
});



// Récupérer tous les équipements
app.get('/equipments', (req, res) => {
    res.json(equipments);
});

// Récupérer un équipement par ID
app.get('/equipments/:id', (req, res) => {
    const equipmentId = req.params.id;
    const equipment = equipments.find(e => e.id === equipmentId);

    if (!equipment) {
        return res.status(404).json({ message: 'Équipement non trouvé' });
    }

    res.json(equipment);
});

// Mettre à jour un équipement (accessible uniquement aux administrateurs)
app.put('/equipments/:id', authenticate, (req, res) => {
    if (!hasRole(req.user.id, 'admin')) {
        return res.status(403).json({ message: 'Accès interdit.  Seuls les administrateurs peuvent modifier les équipements.' });
    }

    const equipmentId = req.params.id;
    const equipmentIndex = equipments.findIndex(e => e.id === equipmentId);

    if (equipmentIndex === -1) {
        return res.status(404).json({ message: 'Équipement non trouvé' });
    }

    const updatedEquipment = {
        ...equipments[equipmentIndex],
        ...req.body, // Permet de mettre à jour seulement les champs envoyés dans la requête
    };

    equipments[equipmentIndex] = updatedEquipment;
    logActivity(req.user.id, 'Update Equipment', { equipmentId, changes: req.body });
    res.json(updatedEquipment);
});

// Supprimer un équipement (accessible uniquement aux administrateurs)
app.delete('/equipments/:id', authenticate, (req, res) => {
    if (!hasRole(req.user.id, 'admin')) {
        return res.status(403).json({ message: 'Accès interdit.  Seuls les administrateurs peuvent supprimer des équipements.' });
    }

    const equipmentId = req.params.id;
    equipments = equipments.filter(e => e.id !== equipmentId);
    logActivity(req.user.id, 'Delete Equipment', { equipmentId });
    res.status(204).send(); // No Content
});



// --------------------------------------------------
// Routes pour les réservations
// --------------------------------------------------

// Créer une réservation
app.post('/reservations', authenticate, (req, res) => {
    const { equipmentId, userId, startTime, endTime } = req.body;

    // Validation basique
    if (!equipmentId || !userId || !startTime || !endTime) {
        return res.status(400).json({ message: 'Données de réservation incomplètes.' });
    }

    // Vérifier si l'équipement existe
    const equipment = equipments.find(e => e.id === equipmentId);
    if (!equipment) {
        return res.status(404).json({ message: 'Équipement non trouvé.' });
    }

    // Vérifier les conflits de réservation
    const hasConflict = reservations.some(reservation =>
        reservation.equipmentId === equipmentId &&
        ((startTime >= reservation.startTime && startTime < reservation.endTime) ||
         (endTime > reservation.startTime && endTime <= reservation.endTime) ||
         (startTime <= reservation.startTime && endTime >= reservation.endTime))
    );

    if (hasConflict) {
        return res.status(409).json({ message: 'Cet équipement est déjà réservé pour cette plage horaire.' });
    }

    const newReservation = {
        id: uuidv4(),
        equipmentId,
        userId,
        startTime,
        endTime,
        status: 'pending', // ou 'confirmed', 'cancelled', etc.
    };

    reservations.push(newReservation);
    logActivity(req.user.id, 'Create Reservation', { reservationId: newReservation.id, equipmentId });
    res.status(201).json(newReservation);
});


// Récupérer toutes les réservations
app.get('/reservations', (req, res) => {
    res.json(reservations);
});

// Récupérer une réservation par ID
app.get('/reservations/:id', (req, res) => {
    const reservationId = req.params.id;
    const reservation = reservations.find(r => r.id === reservationId);

    if (!reservation) {
        return res.status(404).json({ message: 'Réservation non trouvée' });
    }

    res.json(reservation);
});


// Annuler une réservation (seulement par l'utilisateur qui a fait la réservation ou un admin)
app.delete('/reservations/:id', authenticate, (req, res) => {
    const reservationId = req.params.id;
    const reservationIndex = reservations.findIndex(r => r.id === reservationId);

    if (reservationIndex === -1) {
        return res.status(404).json({ message: 'Réservation non trouvée' });
    }

    const reservation = reservations[reservationIndex];

    // Vérifier si l'utilisateur a le droit d'annuler la réservation
    if (reservation.userId !== req.user.id && !hasRole(req.user.id, 'admin')) {
        return res.status(403).json({ message: 'Vous n\'êtes pas autorisé à annuler cette réservation.' });
    }

    reservations.splice(reservationIndex, 1); // Supprime la réservation du tableau
    logActivity(req.user.id, 'Cancel Reservation', { reservationId });
    res.status(204).send(); // No Content
});

// --------------------------------------------------
// Routes pour la gestion des utilisateurs (exemple très basique)
// --------------------------------------------------

// Créer un utilisateur (pour l'exemple, pas de système d'inscription complexe)
app.post('/users', (req, res) => {
    const newUser = {
        id: uuidv4(),
        username: req.body.username,
        password: req.body.password, // NE JAMAIS stocker les mots de passe en clair en production!  Utiliser bcrypt ou une autre méthode de hashage.
        roles: ['user'], // Rôle par défaut
    };
    users.push(newUser);
    res.status(201).json(newUser);
});

// Récupérer tous les utilisateurs (accessible uniquement aux administrateurs)
app.get('/users', authenticate, (req, res) => {
    if (!hasRole(req.user.id, 'admin')) {
        return res.status(403).json({ message: 'Accès interdit. Seuls les administrateurs peuvent lister les utilisateurs.' });
    }
    res.json(users);
});


// --------------------------------------------------
// Routes pour l'audit et les rapports
// --------------------------------------------------

// Récupérer le journal d'audit (accessible uniquement aux administrateurs)
app.get('/audit-log', authenticate, (req, res) => {
    if (!hasRole(req.user.id, 'admin')) {
        return res.status(403).json({ message: 'Accès interdit. Seuls les administrateurs peuvent consulter le journal d\'audit.' });
    }
    res.json(auditLog);
});

// Signaler une non-conformité (dommages, utilisation abusive, etc.)
app.post('/non-conformities', authenticate, (req, res) => {
    const { equipmentId, description } = req.body;

    if (!equipmentId || !description) {
        return res.status(400).json({ message: 'L\'ID de l\'équipement et la description sont requis.' });
    }

    const newNonConformity = {
        id: uuidv4(),
        equipmentId,
        userId: req.user.id,
        description,
        timestamp: formatDate(new Date()),
        status: 'open', // ou 'resolved', 'in progress', etc.
    };

    nonConformities.push(newNonConformity);
    logActivity(req.user.id, 'Report Non-Conformity', { nonConformityId: newNonConformity.id, equipmentId });
    res.status(201).json(newNonConformity);
});

// Récupérer les rapports de non-conformité (accessible uniquement aux administrateurs)
app.get('/non-conformities', authenticate, (req, res) => {
    if (!hasRole(req.user.id, 'admin')) {
        return res.status(403).json({ message: 'Accès interdit. Seuls les administrateurs peuvent consulter les rapports de non-conformité.' });
    }
    res.json(nonConformities);
});



// --------------------------------------------------
// Démarrage du serveur
// --------------------------------------------------

const port = 3000;
app.listen(port, () => {
    console.log(`Serveur démarré sur le port ${port}`);
});
